Update log
==========

08-29-2016
----------

* Updated the directory so it links to /~ not /~.html
* Smoker page update for Fall 2016
* Started logging updates
